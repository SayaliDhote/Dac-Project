package com.app.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.pojos.Owner;
import com.app.repository.IOwnerRepository;


@Service          // mandatory
@Transactional   // optional since it's by default already added on JpaRepository
public class OwnerServiceImpl implements IOwnerService {

	
	    //dependency
		@Autowired
		private IOwnerRepository ownerRepo;
		
		
		//list all owners
		@Override
		public List<Owner> getAllOwners() {
			System.out.println(" Owner service impl class..."+ownerRepo.getClass().getName());
			return ownerRepo.findAll();
		}

       //get owner details by id
     	@Override
		public Owner getOwnerDetails(int ownerId) {
			System.out.println("Owner service impl class..."+ownerRepo.getClass().getName());
			Optional<Owner> optionalOwner = ownerRepo.findById(ownerId);
			if (optionalOwner.isPresent())
				return optionalOwner.get();
			// if owner is not found : throw custom exception
			throw new ResourceNotFoundException ("Owner Not Found : Invalid ID " + ownerId);
		}

     	@Override
    	public Owner addOwnerDetails(Owner o) {
    		
    		return ownerRepo.save(o);
    	}// auto dirty checking --insert query --L1 cache destroyed --cn rets cn pool
    		// --persistence context is closed
    		// returns detached POJO to the caller(REST controller)

		
		@Override
		public Owner updateOwnerDetails(Owner o) {
			// check if Owner exists
			Optional<Owner> optional = ownerRepo.findById(o.getOwnerId());
			if (optional.isPresent())
				return ownerRepo.save(o); // update
			// if owner is not found : throw custom exception
			throw new ResourceNotFoundException("Owner Not Found : Invalid  Owner  id " + o.getOwnerId());

		}
		// auto dirty checking --update query --L1 cache destroyed --cn rets cn pool
		// --persistence context is closed
		// returns detached POJO to the caller(REST controller)

		
		
		@Override
		public void deleteOwnerDetails(int ownerId) {
			// check if owner exists : yes : delete , otherwise throw exception
			Optional<Owner> optional = ownerRepo.findById(ownerId);
			if (optional.isPresent())
				ownerRepo.deleteById(ownerId); //delete
			else
				// if owner is not found : throw custom exception
				throw new ResourceNotFoundException("Owner Not Found : Invalid Owner id " + ownerId);

		}

		@Override
		public Owner fetchOwnerByEmailAndPassword(String email, String password) {
			return ownerRepo.findByEmailAndPassword(email, password);
		}
	
     	
		
}
