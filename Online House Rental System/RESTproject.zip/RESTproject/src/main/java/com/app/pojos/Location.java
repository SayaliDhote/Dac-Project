package com.app.pojos;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="locations")
public class Location implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="location_id")
	private Integer locationId; 
	@Column(name="building_name",length=50)
	private String buildingName; 
	@Column(name="street",length=50)
	private String street ;  
	@Column(name="landmark",length=50)
	private String landmark;
	@Column(name="locality",length=50)
	private String locality; 
    @Column(name="area",length=50)
	private String area;   
    @Column(name="pincode")
	private Integer pincode;
	
	public Location() {
		System.out.println("In location's constructor......................"+getClass().getName());
		
	}

	public Location(Integer locationId, String buildingName, String street, String locality, String landmark,
			String area, Integer pincode) {
		super();
		this.locationId = locationId;
		this.buildingName = buildingName;
		this.street = street;
		this.locality = locality;
		this.landmark = landmark;
		this.area = area;
		this.pincode = pincode;
	}



	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", buildingName=" + buildingName + ", street=" + street
				+ ", locality=" + locality + ", landmark=" + landmark + ", area=" + area + ", pincode=" + pincode + "]";
	}
	
	//linking location with property
	//one property---one location
	@JsonIgnoreProperties("property")
	@OneToOne(mappedBy = "location",cascade = CascadeType.ALL, fetch = FetchType.EAGER,orphanRemoval = true)
	private  property property;

	public property getProperty() {
		return property;
	}

	public void setProperty(property property) {
		this.property = property;
	}
     
	
	
	
}
