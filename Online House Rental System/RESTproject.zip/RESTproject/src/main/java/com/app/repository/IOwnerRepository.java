package com.app.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Owner;

public interface IOwnerRepository extends JpaRepository<Owner, Integer> {

	 public Owner findByEmailAndPassword(String email, String password);

	

}
