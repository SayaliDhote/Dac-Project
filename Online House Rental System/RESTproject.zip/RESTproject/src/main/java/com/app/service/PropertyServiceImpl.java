package com.app.service;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.pojos.Owner;
import com.app.pojos.property;
import com.app.repository.IPropertyRepository;

@Service
@Transactional
public class PropertyServiceImpl implements IPropertyService {

	//dependency
	@Autowired
	private IPropertyRepository propertyRepo;
	
	
	//list all properties
	@Override
	public List<property> getAllProperty() {
		System.out.println("dao impl class..."+propertyRepo.getClass().getName());
		return propertyRepo.findAll();
	}

	//get property details by id
	@Override
	public Optional<property> getPropertyDetails(int property_id) {
		System.out.println("dao impl class..."+propertyRepo.getClass().getName());
		return propertyRepo.findById(property_id);
	}

   
	//add property details
 	@Override
	public property addPropertyDetails(property p) {
		
		return propertyRepo.save(p);
	}// auto dirty checking --insert query --L1 cache destroyed --cn rets cn pool
		// --persistence context is closed
		// returns detached POJO to the caller(REST controller)

	@Override
	public property updatePropertyDetails(property p) {
		// check if Owner exists
					Optional<property> optional =  propertyRepo.findById(p.getPropertyId());
					if (optional.isPresent())
						return propertyRepo.save(p); // update
					// if owner is not found : throw custom exception
					throw new ResourceNotFoundException("Owner Not Found : Invalid  Owner  id " + p.getPropertyId());

		
	}

	
/*	//add property details
	@Override
	public Object saveProperty(property p) {
		System.out.println("dao impl class..."+dao.getClass().getName());
		return dao.save(p);
	}

	//@Override
	/*public void deleteById(@Min(1) @Max(1000) int propertyId) {
		// TODO Auto-generated method stub
		System.out.println("dao impl class..."+dao.getClass().getName());
		return dao.deleteById(propertyId);
	}
	*/
}
