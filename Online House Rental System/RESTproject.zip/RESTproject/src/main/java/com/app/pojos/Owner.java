package com.app.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import java.io.Serializable;
import java.util.Set;
@Entity
@Table(name="owners")

public class Owner implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="owner_id")
	private Integer ownerId;
	
	@Column(name="password",length = 50)
	private String password;
	
	@Column(name="first_name",length = 50)
	private String firstName;
	
	@Column(name="last_name",length = 50)
	private String lastName;
	
    @Column(name="email",length = 50,unique = true)
	private String email;
	
    @Column(name="contact_number",length=50)
	private String contactNumber;
	
	@Transient        
	//this annotation is used to indicate that a field is not to be persisted or ignore fields to save in the database
	private String confirmPassword;

	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	public Owner() {
		System.out.println("In Owners constructor................... "+getClass().getName());
	}
	
	public Owner(Integer ownerId, String password, String firstName, String lastName, String email,
			 String contactNumber) {
		super();
		this.ownerId = ownerId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
	
	}
	
	
	
	public Integer getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber( String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "Owner [ownerId=" + ownerId + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", contactNumber=" + contactNumber +"]";
	}
	
	  //linking owner with properties
	  //one owner multiple properties
	  @JsonIgnoreProperties("owner")
	  @OneToMany(mappedBy = "owner",cascade = CascadeType.ALL,fetch = FetchType.EAGER,orphanRemoval = true)
	  private Set<property> properties;


	
	
	
}
