package com.app.service;

import java.util.List;
import com.app.pojos.Owner;

public interface IOwnerService {

	
	    //list all owners
	   //add a method to List all owners
	    List<Owner> getAllOwners();

	    //get owner details by id
	    //add a method to get specific owner details by its id
		Owner getOwnerDetails(int ownerId);
		
		//add new owner details
        Owner addOwnerDetails(Owner o);//o : transient 
      
        //update owner details
        Owner updateOwnerDetails(Owner o);//o : detached
        
        //delete  Owner details
        void deleteOwnerDetails(int ownerId);

        //owner login
		Owner fetchOwnerByEmailAndPassword(String email, String  password);
		
			
}
