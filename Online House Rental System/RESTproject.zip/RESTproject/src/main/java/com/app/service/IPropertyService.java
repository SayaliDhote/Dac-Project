package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.app.pojos.Owner;
import com.app.pojos.property;

public interface IPropertyService {
	
       //list all properties
	   List<property> getAllProperty();
	
       //get property details by id
	   Optional<property> getPropertyDetails(int property_id);

	   //add new property details
	   property addPropertyDetails(property p);//p : transient 

	   property updatePropertyDetails(property p);
     

	//delete the property
	//void deleteById(@Min(1) @Max(1000) int propertyId);
}
