package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Tenant;

public interface ITenantRepository extends JpaRepository<Tenant, Integer> {

}
