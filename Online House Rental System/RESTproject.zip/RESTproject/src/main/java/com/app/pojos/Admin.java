
package com.app.pojos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "admin")
public class Admin implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "admin_id")
	private Integer adminId;
	@Column(name="password",length = 50)
    private String password;
    @Column(name = "first_name",length = 50)
	private String firstName;
	@Column(name = "last_name",length = 50)
	private String lastName;
	@Column(name="email",length = 50,unique = true)
	private String email;
	@Column(name="contact_number",length=50)
	private  String contactNumber;
	
	       
	//this annotation is used to indicate that a field is not to be persisted or ignore fields 
	//to save in the database
	@Transient 
	private String confirmPassword;

	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	public Admin() {
		System.out.println("In Admin's constructor...................."+getClass().getName());
	}
	public Admin(Integer adminId, String password, String firstName, String lastName, String email,
			 String contactNumber) {
		super();
		this.adminId = adminId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public  String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber( String contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", contactNumber=" + contactNumber + "]";
	}
	
	
	
}
