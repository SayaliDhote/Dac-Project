package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.ShortlistedProperties;

public interface IShortlistedPropertiesRepository extends JpaRepository<ShortlistedProperties, Integer>{

}
