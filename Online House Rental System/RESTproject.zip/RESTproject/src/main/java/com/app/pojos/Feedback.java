

package com.app.pojos;
import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="Feedbacks")
public class Feedback implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="feedback_id",length=50)
	private Integer feedbackId; 
	@Column(name="high_rent",length=50)
	private String highRent; 
	private String highDeposit;
	@Column(name="is_broker",length=50)
	private String isBroker; 
	@Column(name="about_property",length=100)       
	private String About_property;
	
	public Feedback() {
		System.out.println("In feedback's constructor...................."+getClass().getName());
		
	}

	public Feedback(Integer feedbackId, String highRent, String highDeposit,
			String isBroker, String about_property) {
		super();
		this.feedbackId = feedbackId;
		this.highRent = highRent;
		this.highDeposit = highDeposit;
		this.isBroker = isBroker;
		About_property = about_property;
	}

	public Integer getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}

    public String getHighRent() {
		return highRent;
	}

	public void setHighRent(String highRent) {
		this.highRent = highRent;
	}

	public String getHighDeposit() {
		return highDeposit;
	}

	public void setHighDeposit(String highDeposit) {
		this.highDeposit = highDeposit;
	}

	public String getIsBroker() {
		return isBroker;
	}

	public void setIsBroker(String isBroker) {
		this.isBroker = isBroker;
	}

	public String getAbout_property() {
		return About_property;
	}

	public void setAbout_property(String about_property) {
		About_property = about_property;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", highRent=" + highRent + ", highDeposit=" + highDeposit + ", isBroker=" + isBroker
				+ ", About_property=" + About_property + "]";
	}    
     
	 //mapping the tenant to feedbacks
	 //one tenant can give multiple feedbacks
	@JsonIgnoreProperties("feedback")
	@ManyToOne
	@JoinColumn(name="property_id",nullable = false)
	private property property;

	public property getProperty() {
		return property;
	}

	public void setProperty(property property) {
		this.property = property;
	} 
	
     //mapping feedback with properties
    //one property---multiple feebacks
	@JsonIgnoreProperties("tenant")
	@ManyToOne
	@JoinColumn(name="tenant_id",nullable = false)
	private Tenant tenant;

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

	
	
	
	
}
