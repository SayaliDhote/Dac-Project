
package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name="Shortlisted_properties")

public class ShortlistedProperties{
	  
    @Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="shortlisted_properties_id")
	private Integer shortlistedPropertiesId; 
    @Column(name="tenant_id")
    private Integer tenant_id;
    @Column(name="property_id")
    private Integer property_id;
    
    
    
    public ShortlistedProperties() {
    	System.out.println("In shortlisted Properties constructor................... "+getClass().getName());
	}



	

	public ShortlistedProperties(Integer shortlistedPropertiesId, Integer tenant_id, Integer property_id) {
		super();
		this.shortlistedPropertiesId = shortlistedPropertiesId;
		this.tenant_id = tenant_id;
		this.property_id = property_id;
	
	}

	public Integer getShortlistedPropertiesId() {
		return shortlistedPropertiesId;
	}


    public void setShortlistedPropertiesId(Integer shortlistedPropertiesId) {
		this.shortlistedPropertiesId = shortlistedPropertiesId;
	}


	public Integer getTenant_id() {
		return tenant_id;
	}
    
	public void setTenant_id(Integer tenant_id) {
		this.tenant_id = tenant_id;
	}

   public Integer getProperty_id() {
		return property_id;
	}

   public void setProperty_id(Integer property_id) {
		this.property_id = property_id;
	}

    @Override
	public String toString() {
		return "ShortlistedProperties [shortlistedPropertiesId=" + shortlistedPropertiesId + ", tenant_id=" + tenant_id
				+ ", property_id=" + property_id + ", tenant=" + tenant + "]";
	}



    //linking shortlisted properties with tenants
    @JsonIgnoreProperties("shortlistedproperty")
    @ManyToOne
    @JoinColumn(name="tenant_id",nullable = false,insertable = false,updatable = false)
    private Tenant tenant;

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}
} 
