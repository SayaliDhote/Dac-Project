package com.app.service;

public class AdminServiceImpl {

}
