package com.app.pojos;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Properties")

public class property{
    
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="property_id")
	@JsonProperty("id")
	private Integer propertyId; 
	
	
	@Column(name="deposit")
	//@NotBlank(message="deposit  can't be blank")
	private double deposit; 
	
	@Min(5000)
	@Column(name="rent")
	private double rent;
	
	//@NotBlank(message="build up area must be mentioned")
	@Column(name="buildup_area_in_sqft")
	private double buildupArea; 
	
	//@NotBlank(message="property type must be supplied")
	@Column(name="property_type",length=50)
	private String propertyType; 
	
	//@NotBlank(message="furnished  or not must be mentioned")
	@Column(name="furnishing",length=30)
	private String furnishing; 
	
	//@NotBlank(message="availiblity must be mentioned")
	@Column(name="availiblity",length=30)
	private String availiblity;   
	
	//@NotBlank(message="preferred tenants must be supplied")
	@Column(name="preferred_tenants",length=30)
	private String preferredTenants;
	
	//@NotBlank(message="parking available or not must be supplied")
	@Column(name="parking",length=30)
	private String parking;  
	
    public property() {
		System.out.println("In property constructor.................."+getClass().getName());
	}
    
	public property(Integer propertyId, double deposit, double rent, double buildupArea, String propertyType,
			String furnishing, String availiblity, String preferredTenants, String parking) {
		super();
		this.propertyId = propertyId;
		this.deposit = deposit;
		this.rent = rent;
		this.buildupArea = buildupArea;
		this.propertyType = propertyType;
		this.furnishing = furnishing;
		this.availiblity = availiblity;
		this.preferredTenants = preferredTenants;
		this.parking = parking;
		}
	
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getRent() {
		return rent;
	}
	public void setRent(double rent) {
		this.rent = rent;
	}
	public double getBuildupArea() {
		return buildupArea;
	}
	public void setBuildupArea(double buildupArea) {
		this.buildupArea = buildupArea;
	}
	public String getpropertyType() {
		return propertyType;
	}
	public void setType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getFurnishing() {
		return furnishing;
	}
	public void setFurnishing(String furnishing) {
		this.furnishing = furnishing;
	}
	public String getAvailiblity() {
		return availiblity;
	}
	public void setAvailiblity(String availiblity) {
		this.availiblity = availiblity;
	}
	public String getPreferredTenants() {
		return preferredTenants;
	}
	public void setPreferredTenants(String preferredTenants) {
		this.preferredTenants = preferredTenants;
	}
	public String getParking() {
		return parking;
	}
	public void setParking(String parking) {
		this.parking = parking;
	}
	
	@Override
	public String toString() {
		return "property [propertyId=" + propertyId + ", deposit=" + deposit + ", rent=" + rent + ", buildupArea="
				+ buildupArea + ", propertyType=" + propertyType + ", furnishing=" + furnishing + ", availiblity=" + availiblity
				+ ", preferredTenants=" + preferredTenants + ", parking=" + parking + "]";
	}      
   
	
	// mapping the property with the owner
	//one owner----many properties
	@JsonIgnoreProperties("owner")
	@ManyToOne
	@JoinColumn(name="owner_id",nullable = false)
	private Owner owner;
	
	public Owner getOwner() {
		return owner;
	}
	public void setOwner(Owner owner) {
		this.owner = owner;
	}

    //mapping the property with location
	//@JsonManagedReference
	@JsonIgnoreProperties("property")
	@OneToOne
	@JoinColumn(name="location_id",nullable = false)
    private  Location location;

    public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}

	
	//linking the property with feedback
	@JsonIgnoreProperties("property")
	@OneToMany(mappedBy = "property",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<Feedback> feedback;

	
	

}
