package com.app.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ErrorResponse;
import com.app.pojos.Owner;

import com.app.service.IOwnerService;


@RestController
@RequestMapping(value="/owner",produces = "application/json")
//http://localhost:7070/owner
@CrossOrigin(origins="http://localhost:4200")
public class OwnerController {

	   // dependency : service layer i/f
		@Autowired
		private IOwnerService ownerService;

		public OwnerController() {
			System.out.println("In constructor of............"+getClass().getName());
		}
		//RESTful/API  end point
		
		// add a request handling method to return representation of list of available owner 
		// get list of all owners
		@GetMapping
		public ResponseEntity<?> listAllOwners()
		{
			System.out.println("in list all owners");
		     List<Owner> owners=ownerService.getAllOwners();
		     // check if list is empty
		      if(owners.isEmpty())
		    	 return new ResponseEntity<> (HttpStatus.NO_CONTENT);
		    //for non empty list
		         return new ResponseEntity<>(owners,HttpStatus.OK);
		}
		
		// add a request handling method to return representation of selected owner by id
		// OR in case of invalid id
		// SC 404
		//Get specific owner details
		
		@GetMapping("/{ownerId}")
		public ResponseEntity<?> getOwnerDetailsById(@PathVariable int ownerId) {
			System.out.println("in get owner details " +ownerId);
			
			
			try {
				return ResponseEntity.ok(ownerService.getOwnerDetails(ownerId));
			} catch (RuntimeException e) {
				System.out.println("err in controller " + e);
			}
			ErrorResponse resp = new ErrorResponse("Owner Id Invalid", "Must Supply valid Owner Id");
			
			return new ResponseEntity<>(resp,HttpStatus.NOT_FOUND);
		 }
	
		
		//add new REST end point : to add a owner
		@PostMapping
		public ResponseEntity<?> addNewOwner(@RequestBody Owner o ) {
			System.out.println("in add new owner " + o);
			return ResponseEntity.ok(ownerService.addOwnerDetails(o));
		}
		
		// add new REST end point : to update existing owner
		@PutMapping
		public ResponseEntity<?> updateOwnerDetails(@RequestBody Owner o) {
			System.out.println("in update owner " + o);
			try {
				return ResponseEntity.ok(ownerService.updateOwnerDetails(o));
			} catch (RuntimeException e) {
				System.out.println("error in controller " + e);
			}
          ErrorResponse resp = new ErrorResponse("Owner Id Invalid", "Must Supply valid Owner Id");
			
			return new ResponseEntity<>(resp,HttpStatus.NOT_FOUND);
			
		}
		
		//add REST end point to delete owner details
		@DeleteMapping("/{ownerId}")
		public void deleteOwnerDetails(@PathVariable int ownerId) {
			System.out.println("in delete owner details " + ownerId);
			try {
				ownerService.deleteOwnerDetails(ownerId);
				
			} catch (RuntimeException e) {
				System.out.println("error in controller " + e);
			}
		}
		
		
		    @PostMapping("/login")
		   //  @CrossOrigin(origins = "http://localhost:4200")
		     public Owner ownerLogin(@RequestBody Owner o)throws Exception{
		    	 String tempEmail=o.getEmail();
		    	 String tempPass=o.getPassword();
		    	 
		    	 Owner ownerobj= null;
		    	 if(tempEmail !=null && tempPass!=null) {
		    		 ownerobj=ownerService.fetchOwnerByEmailAndPassword(tempEmail, tempPass);
		    	 }
		    	 if(ownerobj == null) {
		    		 throw new Exception("Wrong credentials");
		    	 }
		    	 return ownerobj;
		     }

		
}
