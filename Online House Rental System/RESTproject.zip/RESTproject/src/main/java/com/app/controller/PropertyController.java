package com.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Owner;
import com.app.pojos.property;
import com.app.service.IPropertyService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(value="/properties",produces = "application/json")
public class PropertyController {

	//dependency
	@Autowired
	private IPropertyService propertyService;
	
	
	public PropertyController() {
		System.out.println("In constructor of ................"+getClass().getName());
	}
	
	//RESTful API  end point
	
	// get list of all properties
	@GetMapping
	public ResponseEntity<?> listAllProperties()
	{
		System.out.println("in list all properties");
	     List<property> properties=propertyService.getAllProperty();
	     if(properties.isEmpty())
	    	 return new ResponseEntity<> (HttpStatus.NO_CONTENT);
	
	    return new ResponseEntity<>(properties,HttpStatus.OK);
	}
	
	
	
	@GetMapping("/{property_id}")
	public ResponseEntity<?> getPropertyDetailsById(@PathVariable int property_id) {
		System.out.println("in get property details " +property_id);
		Optional<property> optional = propertyService.getPropertyDetails(property_id);
		if (optional.isPresent())
	            //return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		      // invalid id
		ErrorResponse resp = new ErrorResponse("property Id Invalid", "Must Supply valid property Id");
		return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
	 }
	
	// add new property details : Create : POST
		// @RequestBody : un marshalling (json ---> java obj)
		//plus validation rules will be invoked from the POJO.
	
	/*@Modifying
	@Query(
	  value = 
	    "insert into properties(availiblity,buildup_area_in_sqft,  deposit,furnishing,parking, preferred_tenants ,property_type ,rent , location_id, owner_id ) "
	    + "values (:availiblity,:buildup_area_in_sqft, :deposit,:furnishing,:parking, :preferred_tenants ,:property_type ,:rent , :location_id, :owner_id ) "
		  ,nativeQuery = true)*/
		@PostMapping 
		public ResponseEntity<?> addNewProperty(@RequestBody @Valid property p) {
			System.out.println("in add new property " + p);
			return  ResponseEntity.ok(propertyService.addPropertyDetails(p));
		}

		// add new REST end point : to update existing owner
				@PutMapping
				public ResponseEntity<?> updatePropertyDetails(@RequestBody property p) {
					System.out.println("in update property " + p);
					try {
						return ResponseEntity.ok(propertyService.updatePropertyDetails(p));
					} catch (RuntimeException e) {
						System.out.println("error in controller " + e);
					}
		          ErrorResponse resp = new ErrorResponse("property Id Invalid", "Must Supply valid property Id");
					
					return new ResponseEntity<>(resp,HttpStatus.NOT_FOUND);
					
				}
		
		
		
		
		

		
}
