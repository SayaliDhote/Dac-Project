
package com.app.pojos;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="tenants")

public class Tenant implements Serializable{
    
    @Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tenant_id")
	private Integer tenantId; 
	@Column(name="password",length=30)
	private String password;
	@Column(name="first_name",length=30)
	private String firstName;
	@Column(name="last_name",length=30)
	private String lastName;
	@Column(name="email",length=30,unique = true)
	private String email;
	@Column(name="contact_number")
	private String contactNumber;
	
	@Transient        
	//this annotation is used to indicate that a field is not to be persisted or ignore fields to save in the database
	private String confirmPassword;

	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	public Tenant() {
		System.out.println("In tenant constructor..........................."+getClass().getName());
	}
	
	public Tenant(Integer tenantId, String password, String firstName, String lastName, String email,
			String contactNumber) {
		super();
		this.tenantId = tenantId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	
	public Integer getTenantId() {
		return tenantId;
	}
	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "Tenant [tenantId=" + tenantId + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", contactNumber=" + contactNumber + "]";
	}

   
	 //mapping the tenant to shortlisted properties
	 //one tenant can shortlisted multiple properties
	 @JsonIgnoreProperties("tenant")
	 @OneToMany(mappedBy = "tenant",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 private Set<ShortlistedProperties> shortlistedProperties;

	
	
	//mapping the tenant to feedbacks
	//one tenant can give multiple feedbacks
	@JsonIgnoreProperties("tenant")
	@OneToMany(mappedBy = "tenant",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<Feedback> feedback;

	
	
	
	
	
}
