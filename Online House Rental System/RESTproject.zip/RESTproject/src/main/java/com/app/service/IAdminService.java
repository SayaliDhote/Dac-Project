package com.app.service;

public interface IAdminService {

}
